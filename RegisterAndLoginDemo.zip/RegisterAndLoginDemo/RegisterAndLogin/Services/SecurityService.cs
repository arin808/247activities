﻿using RegisterAndLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegisterAndLogin.Services
{
    public class SecurityService
    {
        SecurityDAO dao = new SecurityDAO();

        public bool IsValid(UserModel user)
        {
            return dao.FindUserByNameAndPassword(user);
        }

    }
}

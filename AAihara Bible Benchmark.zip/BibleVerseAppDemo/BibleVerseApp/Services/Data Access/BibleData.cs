﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BibleVerseApp.Models;
using BibleVerseApp.Services.Utility;
using System.Data.SqlClient;

namespace BibleVerseApp.Services.Data_Access
{
    public class BibleData : DatabaseManager
    {
        // IEnumerable in C# is an interface that defines one method,
        // allowing readonly access to a collection. A collection that 
        // implements IEnumerable can be used with a for-each loop
        public IEnumerable<BibleVerse> GetBibleVerses(VerseSearch searchCriteria)
        {
            string testamentSearch = "";

            //Create the transport list
            List<BibleVerse> searchResults = new List<BibleVerse>();

            using (SqlConnection connection = new SqlConnection(connString))
            {
                connection.Open();

                if(searchCriteria.Testament == "OT")
                {
                    testamentSearch = "AND key_english.t = 'OT'";
                }
                else if(searchCriteria.Testament == "NT")
                {
                    testamentSearch = "AND key_english.t = 'NT'";
                }
                else
                {
                    testamentSearch = "";
                }
                //Define the query
                string query = string.Format(@"SELECT bible.t AS TEXT, bible.b, bible.c AS Chapter, bible.v AS Verse,
	                                            key_english.n AS Book, key_english.t AS Testament, 
	                                            key_genre_english.n AS Genre
                                                FROM {0} bible
                                                JOIN key_english
                                                ON bible.b = key_english.b
                                                JOIN key_genre_english
                                                ON key_english.g = key_genre_english.g
                                                WHERE bible.t LIKE '%{1}%' {2}
                                                ORDER BY bible.b, Chapter, Verse", searchCriteria.BibleVersion, searchCriteria.Text, testamentSearch);
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while(reader.Read())
                        {
                            // Instantiate our BibleVerse class creating an object called verse
                            BibleVerse verse = new BibleVerse();
                            //populate verse object with found verse
                            verse.BookName = reader["Book"].ToString();
                            verse.Chapter = Convert.ToInt32(reader["Chapter"]);
                            verse.Genre = reader["Genre"].ToString();
                            verse.Verse = Convert.ToInt32(reader["Verse"]);
                            if(reader["Testament"].ToString() == "OT")
                            {
                                verse.OT_NT = "Old Testament";
                            }
                            else
                            {
                                verse.OT_NT = "New Testament";
                            }
                            verse.Text = reader["Text"].ToString();

                            searchResults.Add(verse);
                        }
                    }
                }
            }
            return searchResults;
        }
    }
}
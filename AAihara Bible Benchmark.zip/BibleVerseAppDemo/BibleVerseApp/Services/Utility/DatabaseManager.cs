﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BibleVerseApp.Services.Utility
{
    public class DatabaseManager
    {
        //Define the attributes
        public string connString { get; set; }

        /// <summary>
        /// Constructor to set connString
        /// </summary>
        public DatabaseManager()
        {
            this.connString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=dbBible;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        }
    }
}

﻿using BibleVerseApp.Models;
using BibleVerseApp.Services.Data_Access;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BibleVerseApp.Services.Business
{
    public class BibleBusiness
    {
        public IEnumerable<BibleVerse> GetAllVerses(VerseSearch passSearch)
        {
            //Instantiate data access layer
            BibleData passToDataLayer = new BibleData();
            IEnumerable<BibleVerse> allVerses = passToDataLayer.GetBibleVerses(passSearch);
            return allVerses;
        }
    }
}

﻿using Assessment_247.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment_247
{
    public class FormBS
    {
        /// <summary>
        /// Method returns a model with reversed string contents for 
        /// ingredient fields taken from a model as a param
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public FormModel reverse(FormModel model)
        {
            //Take ingredient1 and put to a char array to reverse
            char[] ing1Arr = model.Ingredient1.ToCharArray();
            Array.Reverse(ing1Arr);

            //Make string object from the Array
            string revIng1 = new string(ing1Arr);

            //Take ingredient2 and put to a char array to reverse
            char[] ing2Arr = model.Ingredient2.ToCharArray();
            Array.Reverse(ing2Arr);

            //Make string object from array
            string revIng2 = new string(ing2Arr);

            //Create new model based off of new ingredient data and current name and cal values
            FormModel reversedModel = new FormModel(model.Name, model.Calories, revIng1, revIng2);

            //Return new reversed model
            return reversedModel;

        }
    }
}

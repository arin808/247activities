﻿using Assessment_247.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_247.Controllers
{
    public class AssessmentController : Controller
    {
        public IActionResult Index()
        {
            return View("Menu");
        }

        [HttpPost]
        public IActionResult passData()
        {
            //Retrieve form data and create new model
            string name = Request.Form["Name"];
            int calories = Convert.ToInt32(Request.Form["Calories"]);
            string ingredient1 = Request.Form["Ingredient1"];
            string ingredient2 = Request.Form["Ingredient2"];

            FormModel model = new FormModel(name, calories, ingredient1, ingredient2);

            //Take current model and make string builder for easy read
            StringBuilder modelString = new StringBuilder();
            modelString.Append("<b>Given Data: </b> <br/>");
            modelString.Append("<b>Name: </b>" + model.Name + "<br/>");
            modelString.Append("<b>Calories: </b>" + model.Calories + "<br/>"); ;
            modelString.Append("<b>Ingredient1: </b>" + model.Ingredient1 + "<br/>"); ;
            modelString.Append("<b>Ingredient2: </b>" + model.Ingredient2 + "<br/>");

            //Instantiate Business Layer Method to get a reversed model
            FormBS bs = new FormBS();
            FormModel reversed = bs.reverse(model);

            //Take reversed model and put into string builder for easy reading
            StringBuilder reversedModelString = new StringBuilder();
            reversedModelString.Append("<b>Reversed Ingredient Data: </b> <br/>");
            reversedModelString.Append("<b>Name: </b>" + reversed.Name + "<br/>");
            reversedModelString.Append("<b>Calories: </b>" + reversed.Calories + "<br/>"); ;
            reversedModelString.Append("<b>Ingredient1: </b>" + reversed.Ingredient1 + "<br/>"); ;
            reversedModelString.Append("<b>Ingredient2: </b>" + reversed.Ingredient2 + "<br/>");

            //Create new ViewBags that will be referenced in view after data is submitted
            ViewBag.model = modelString;
            ViewBag.reversed = reversedModelString;

            return View("Menu");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment_247.Models
{
    public class FormModel
    {
        //Declare model properties
        public string Name { get; set; }
        public int Calories { get; set; }
        public string Ingredient1 { get; set; }
        public string Ingredient2 { get; set; }

        //Create model constructor
        public FormModel(string name, int calories, string ingredient1, string ingredient2)
        {
            Name = name;
            Calories = calories;
            Ingredient1 = ingredient1;
            Ingredient2 = ingredient2;
        }
    }
}

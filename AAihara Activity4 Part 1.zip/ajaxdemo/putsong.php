<?php
    
    //the <pre> tags are needed for the json format
    header('Content-Type: application/json');
    echo json_encode($_GET);
?>
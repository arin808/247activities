<?php
    //usually an api service pulls data from a database with an SQL query
    //this is just mock data

    $song1 = array('id'=>1, 'artist'=>'ABBA', 'title'=>"Dancing Queen");
    $song2 = array('id'=>2, 'artist'=>'Queen', 'title'=>"Bohemian Rhapsody");
    $song3 = array('id'=>3, 'artist'=>'Elvis', 'title'=>"Hound Dog");
    $song4 = array('id'=>4, 'artist'=>'Sinatra', 'title'=>"Fly Me to the Moon");
    $song5 = array('id'=>5, 'artist'=>'Beatles', 'title'=>"Hey Jude");

    $arr_list = [$song1, $song2, $song3, $song4, $song5];

    //the <pre> tags are needed for the json format
    header('Content-Type: application/json');
    echo json_encode($arr_list);
?>
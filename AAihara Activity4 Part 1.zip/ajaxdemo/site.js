$(function()
{
    console.log("JQuery is ready.");

    //Respond to the "get songs" button
    $("#get-songs-from-api").click(function()
    {
        console.log("get songs button was clicked");

        $.ajax(
        {
            dataType: "json",
            url: "getsongs.php",
            success: function(songs)
            {
                console.log("Here is the list of songs I got from the server: ");
                console.log(songs);

                $.each(songs, function(i, song)
                {
                    var songstring = '<li>Title: ' + song.title + ' Artist: ' + song.artist + '</li>';
                    $(songstring).appendTo('#songs').hide().fadeIn();
                })
            }
        });
    });

    $("#add-song").click(function()
    {
        //get the contents of the input lines of the form and put it into a JSON object
        var song = 
        {
            title: $('#title').val(),
            artist: $('#artist').val()
        }

        // send the data to the backend server
        $.ajax(
            {
                type:'GET',
                url:'putsong.php',
                dataType: "json",
                data: song,
                success:function(newsong)
                {
                    // our server sends back the song we give
                    // in a real back end, the server would 
                    //store data in the db before sending it back
                    console.log("Here is the song the server sent back to us:");
                    console.log(newsong);
                    var songstring = '<li>Title: ' + newsong.title + ' Artist: ' + newsong.artist +'</li>';
                    $(songstring).appendTo('#songs').hide().fadeIn();
                }
            })
    });
});

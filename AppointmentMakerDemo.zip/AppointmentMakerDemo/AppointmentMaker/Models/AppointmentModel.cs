﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AppointmentMaker.Models
{
    public class AppointmentModel
    {
        [Required]
        [DisplayName("Patient's Full Name")]
        [StringLength(20, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 20 characters")]
        public string patientName { get; set; }

        [Required]
        [DisplayName("Patient's Street Address")]
        [DataType(DataType.Text)]
        [StringLength(20, MinimumLength = 3, ErrorMessage = "Address must be between 3 and 20 characters")]
        public string street { get; set; }

        [Required]
        [DisplayName("Patient's City")]
        [StringLength(20, MinimumLength = 3, ErrorMessage = "City must be between 3 and 20 characters")]
        public string city { get; set; }

        [Required]
        [DisplayName("Patient's Zipcode")]
        [MaxLength(5, ErrorMessage = "Zipcode must be 5 characters")]
        [MinLength(5, ErrorMessage = "Zipcode must be 5 characters")]
        [Range(0,99999)]
        public int zip { get; set; }

        [Required]
        [DisplayName("Patient's Email")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Please enter a valid email")]
        [StringLength(20, MinimumLength = 3)]
        public string email { get; set; }

        [Required(ErrorMessage = "Please enter a valid phone#")]
        [DisplayName("Patient's Phone#")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(20, MinimumLength = 3)]
        public PhoneAttribute phone { get; set; }

        [Required(ErrorMessage = "Appointment Date is required")]
        [DataType(DataType.DateTime)]
        [DisplayName("Appointment Request Date")]
        public DateTime dateTime { get; set; }

        [DataType(DataType.Currency)]
        [Range (90000, 9999999999, ErrorMessage = "Doctors will not see patient's whose net worth is below $90,000")]
        [DisplayName("Patient's Approximate Net Worth")]
        [Required]
        public decimal PatientNetWorth { get; set; }

        [Required]
        [StringLength(20, MinimumLength = 2, ErrorMessage = "Doctor's name must be between 2 and 20 characters")]
        [DisplayName("Primary Doctor's Last Name")]
        public string DoctorName { get; set; }

        [Required]
        [Range(5,10, ErrorMessage = "Doctor's will not see patients whose pain level is below 5")]
        [DisplayName("Patient's perceived level of pain (1 low to 10 high)")]
        public int PainLevel { get; set; }

        public AppointmentModel(string patientName, string street, string city, int zip, string email, PhoneAttribute phone, DateTime dateTime, decimal patientNetWorth, string doctorName, int painLevel)
        {
            this.patientName = patientName;
            this.street = street;
            this.city = city;
            this.zip = zip;
            this.email = email;
            this.phone = phone;
            this.dateTime = dateTime;
            PatientNetWorth = patientNetWorth;
            DoctorName = doctorName;
            PainLevel = painLevel;
        }

        public AppointmentModel()
        {

        }
    }
}

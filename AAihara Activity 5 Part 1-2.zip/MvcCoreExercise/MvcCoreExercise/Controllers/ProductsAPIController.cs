﻿using Bogus;
using Microsoft.AspNetCore.Mvc;
using MvcCoreExercise.Models;
using MvcCoreExercise.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.Description;

namespace MvcCoreExercise.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    // api/productsapi/
    public class ProductsAPIController : ControllerBase
    {
        ProductsDAO repo = new ProductsDAO();

        /// <summary>
        /// Constructor
        /// </summary>
        public ProductsAPIController()
        {
            repo = new ProductsDAO();
        }
        /// <summary>
        /// Index
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ResponseType(typeof(List<ProductDTO>))]
        public IEnumerable<ProductDTO> Index()
        {
            //Get the products
            List<ProductsModel> productList = repo.AllProducts();

            //Use Linq stmt or foreach
            List<ProductDTO> productDTOList = new List<ProductDTO>();

            foreach(ProductsModel p in productList)
            {
                productDTOList.Add(new ProductDTO(p.ID, p.Name, p.Price, p.Description));
            }

            return productDTOList;

            //return repo.AllProducts();
        }
        /// <summary>
        /// Return the search results
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns></returns>
        [ResponseType(typeof(ProductDTO))]
        [HttpGet("searchresults/{searchTerm}")]
        public IEnumerable<ProductDTO> SearchResults(string searchTerm)
        {
            List<ProductsModel> productList = repo.SearchProducts(searchTerm);

            //Use Linq stmt or foreach
            List<ProductDTO> productDTOList = new List<ProductDTO>();

            foreach (ProductsModel p in productList)
            {
                productDTOList.Add(new ProductDTO(p.ID, p.Name, p.Price, p.Description));
            }

            return productDTOList;
            //return productList;
        }
        //public IActionResult SearchForm()
        //{
        //    return View();
        //}
        //public IActionResult Message()
        //{
        //    return View();
        //}

        /// <summary>
        /// Only show one product
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("showoneproduct/{id}")]
        /// Get /api/productsapi/showoneproduct/id
        /// Response type helps the server reply with correct error messages 
        [ResponseType(typeof(ProductDTO))]
        public ActionResult<ProductDTO> ShowOneProduct(int Id)
        {
            ProductsModel product = repo.GetProductByID(Id);

            ProductDTO productDTO = new ProductDTO(product.ID, product.Name, product.Price, product.Description);

            return productDTO;
            //return repo.GetProductByID(Id);
        }
        //Not used in REST api
        /*public IActionResult ShowEditForm(int Id)
        {
            return View(repo.GetProductByID(Id));
        }*/
        /// <summary>
        /// Update a product        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPut("processedit")]
        // PUT /api
        [ResponseType(typeof(List<ProductDTO>))]
        public IEnumerable<ProductDTO> ProcessEdit(ProductsModel product)
        {
            repo.Update(product);

            //Get the products
            List<ProductsModel> productList = repo.AllProducts();

            //Use Linq stmt or foreach
            List<ProductDTO> productDTOList = new List<ProductDTO>();

            foreach (ProductsModel p in productList)
            {
                productDTOList.Add(new ProductDTO(p.ID, p.Name, p.Price, p.Description));
            }

            return productDTOList;

            //return repo.AllProducts();
        }

        [HttpPut("processeditreturnoneitem")]
        [ResponseType(typeof(ProductDTO))]
        public ActionResult<ProductDTO> ProcessEditReturnOneItem(ProductsModel product)
        {
            repo.Update(product);

            ProductsModel updateProduct = repo.GetProductByID(product.ID);

            ProductDTO productDTO = new ProductDTO(updateProduct.ID, updateProduct.Name, updateProduct.Price, updateProduct.Description);

            return productDTO;
            //return repo.GetProductByID(product.ID);
        }
        //public IActionResult Delete(ProductsModel product)
        //{
        //    repo.Delete(product);
        //    return View("Index", repo.AllProducts());
        //}
        //public IActionResult Welcome()
        //{
        //    ViewBag.name = "Billy";
        //    ViewBag.secretNumber = 13;
        //    return View();
        //}
    }
}

﻿using Bogus;
using Microsoft.AspNetCore.Mvc;
using MvcCoreExercise.Models;
using MvcCoreExercise.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace MvcCoreExercise.Controllers
{
    public class ProductsController : Controller
    {
        ProductsDAO repo = new ProductsDAO();

        public ProductsController()
        {
            repo = new ProductsDAO();
        }
        public IActionResult Index()
        {
            return View(repo.AllProducts());
        }
        public IActionResult SearchResults(string searchTerm)
        {
            List<ProductsModel> productList = repo.SearchProducts(searchTerm);

            return View("Index", productList);
        }
        public IActionResult SearchForm()
        {
            return View();
        }
        public IActionResult Message()
        {
            return View();
        }
        public IActionResult ShowOneProduct(int Id)
        {
            return View(repo.GetProductByID(Id));
        }
        public IActionResult ShowEditForm(int Id)
        {
            return View(repo.GetProductByID(Id));
        }
        public IActionResult ProcessEditReturnOneItem(ProductsModel product)
        {
            repo.Update(product);
            return PartialView("_productCard", repo.GetProductByID(product.ID));
        }
        public IActionResult ProcessEdit(ProductsModel product)
        {
            repo.Update(product);
            return View("Index", repo.AllProducts());
        }
        public IActionResult Delete(ProductsModel product)
        {
            repo.Delete(product);
            return View("Index", repo.AllProducts());
        }
        public IActionResult Welcome()
        {
            ViewBag.name = "Billy";
            ViewBag.secretNumber = 13;
            return View();
        }
    }
}

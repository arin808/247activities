﻿$(function ()
{
    // this button click fills the modal form with data and displays it
    $(document).on("click", ".edit-product-button", function (event)
    {
        event.preventDefault();

        // get the existing data from the current record
        var myProdId = $(this).data('id');
        var myProdName = $(this).parent().find('.product-name').html();
        var myProdPrice = $(this).parent().find('.product-price').html().replace("$", "");
        var myProdDesc = $(this).parent().find('.product-description').html();

        // fill in the data entry form
        $(".modal-dialog #Id").val(myProdId);
        $(".modal-dialog #Name").val(myProdName);
        $(".modal-dialog #Price").val(myProdPrice);
        $(".modal-dialog #Description").val(myProdDesc);
    });

    // respond to modal's save
    $("#save-product").click(function ()
    {
        // create a json object in order to submit the new changes to the controller
        var Product = {
            "Id": $('#Id').val(),
            "Name": $('#Name').val(),
            "Price": $('#Price').val(),
            "Description": $('#Description').val()
        };
        console.log(Product);
        doProductUpdate(Product);

        function doProductUpdate(product)
        {
            $.ajax({
                datatype: "json",
                url: '/products/ProcessEditReturnOneItem',
                data: product,
                success: function (data) {
                    console.log(data);
                    $("#card-number-" + Product.Id).html(data);
                }
            });
        }
    });
});
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreExercise.Models
{
    public class ProductsModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }

        public ProductsModel(int id, string name, decimal price, string description)
        {
            ID = id;
            Name = name;
            Price = price;
            Description = description;
        }
        public ProductsModel()
        {

        }
    }
}

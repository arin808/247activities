﻿using MvcCoreExercise.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreExercise.Services
{
    public interface IProductsDataService
    {
        List<ProductsModel> AllProducts();
        List<ProductsModel> SearchProducts(string searchTerm);
        ProductsModel GetProductByID(int id);
        int Insert(ProductsModel product);
        bool Delete(ProductsModel product);
        int Update(ProductsModel product);
    }
}

﻿using MvcCoreExercise.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreExercise.Services
{
    public class ProductsDAO : IProductsDataService
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=dbTest;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public List<ProductsModel> AllProducts()
        {
            List<ProductsModel> foundProducts = new List<ProductsModel>();

            string sqlStatement = "SELECT * FROM dbo.Products";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while(reader.Read())
                    {
                        foundProducts.Add(new ProductsModel((int)reader[0], (string)reader[1], (decimal)reader[2], (string)reader[3]));
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return foundProducts;
        }

        public bool Delete(ProductsModel product)
        {
            bool deleted = false;

            string sqlStatement = "DELETE * FROM dbo.Products WHERE Id = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@Id", product.ID); 
                try
                {
                    connection.Open();
                    if(command.ExecuteNonQuery() > 1)
                    {
                        deleted = true;
                    }
                    else
                    {
                        deleted = false;
                    }                 
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return deleted;
        }

        public ProductsModel GetProductByID(int id)
        {
            ProductsModel product = null;

            string sqlStatement = "SELECT * FROM dbo.Products WHERE Id = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@Id", id);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        product = new ProductsModel ((int)reader[0], (string)reader[1], (decimal)reader[2], (string)reader[3]);
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return product;
        }

        public int Insert(ProductsModel product)
        {
            throw new NotImplementedException();
        }

        public List<ProductsModel> SearchProducts(string searchTerm)
        {
            List<ProductsModel> foundProducts = new List<ProductsModel>();

            string sqlStatement = "SELECT * FROM dbo.Products WHERE Name LIKE @Name";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@Name", '%' + searchTerm + '%');
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        foundProducts.Add(new ProductsModel((int)reader[0], (string)reader[1], (decimal)reader[2], (string)reader[3]));
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return foundProducts;
        }

        public int Update(ProductsModel product)
        {
            // Returns -1 if update fails
            int newIDNum = -1;
            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE dbo.Products SET Name = @Name, Price = @Price, Description = @Description WHERE Id = @Id";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", product.ID);
                command.Parameters.AddWithValue("@Name", product.Name);
                command.Parameters.AddWithValue("@Price", product.Price);
                command.Parameters.AddWithValue("@Description", product.Description);

                try
                {
                    connection.Open();
                    newIDNum = Convert.ToInt32(command.ExecuteScalar());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                return newIDNum;
            }
        }
    }
}

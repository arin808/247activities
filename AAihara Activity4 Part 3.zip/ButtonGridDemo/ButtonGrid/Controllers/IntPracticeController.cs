﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ButtonGrid.Services.Business;
namespace ButtonGrid.Controllers
{

    public class IntPracticeController : Controller
    {
        AddMe intPrac = new AddMe();
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Add(int num1, int num2)
        {
            int sum = intPrac.add(num1, num2);
            ViewBag.calc = String.Format("Sum of {0} and {1} = {2}", num1, num2, sum);

            return View("Index", sum);
        }
    }
}

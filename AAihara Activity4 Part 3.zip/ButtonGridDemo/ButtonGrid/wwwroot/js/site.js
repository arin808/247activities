﻿$(function ()
{
    console.log("Page is ready");
    $(document).on("click", ".game-button", function (event)
    {
        event.preventDefault();

        var buttonNumber = $(this).val();
        console.log("Button: " + buttonNumber + " was clicked");

        doButtonUpdate(buttonNumber);
        checkWin();
    });
});

function doButtonUpdate(buttonNumber)
{
    $.ajax(
    {
        datatype: 'json',
        method: 'POST',
        url: '/button/ShowOneButton',
        data:
        {
            "buttonNumber": buttonNumber
        },
        success: function (data)
        {
            console.log(data);
            $("#" + buttonNumber).html(data);
        }
    });
};

function checkWin() {
    $.ajax(
        {
            datatype: 'json',
            method: 'GET',
            url: '/button/winCheck',
            data: {},
            success: function (data) {
                console.log(data);
                $('#overStatus').html(data);
            }
        });
};
/*$(document).ready(function () {
    $(document).on("mousedown", ".game-button", function (e) {
        if (e.button == 2) {
            var buttonNumber = $(this).val();
            //alert("Right mouse click on button: " + buttonNumber);
            doButtonUpdate(buttonNumber, "/Button/RightClickShowOneButton");
        }
    });
});*/


/*$(document).bind("contextmenu", function (e)
{
    e.preventDefault();
    console.log("Right click. Prevent context");
});*/
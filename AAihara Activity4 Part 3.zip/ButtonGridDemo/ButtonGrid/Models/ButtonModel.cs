﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ButtonGrid.Models
{
    public class ButtonModel
    {
        public int Id { get; set; }

        public int ButtonState { get; set; }

        public ButtonModel()
        {

        }
        /// <summary>
        /// Cnostructor to initialize variables
        /// </summary>
        /// <param name="id"></param>
        /// <param name="buttonState"></param>
        public ButtonModel(int id, int buttonState)
        {
            Id = id;
            ButtonState = buttonState;
        }
    }
}

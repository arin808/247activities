﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ButtonGrid.Models;

namespace ButtonGrid.Services.Business
{
    public class Minesweeper
    {
        public bool sameColor(List<ButtonModel> buttons)
        {
            // Return true if all the boxes are the same color

            var firstBoxColor = buttons.ElementAt(0).ButtonState;
            bool sameColor = false;
            for (int i = 1; i < buttons.Count; i++)
            {
                if (buttons.ElementAt(i).ButtonState == firstBoxColor)
                {
                    sameColor = true;
                }
                else
                {
                    sameColor = false;
                    return sameColor;
                }
            }
            return sameColor;
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ButtonGrid.Models;
using ButtonGrid.Services.Business;
namespace ButtonGrid.Controllers
{
    public class ButtonController : Controller
    {
        // Create list of buttons
        static List<ButtonModel> buttons = new List<ButtonModel>();

        // Define random object
        Random random = new Random();

        // Grid size
        const int GRID_SIZE = 25;
        Minesweeper colorTest = new Minesweeper();
        public IActionResult Index()
        {
            // When the page loads, generate some new buttons
            buttons.Add(new ButtonModel(0, 0));
            buttons.Add(new ButtonModel(1, 3));
            buttons.Add(new ButtonModel(2, 4));
            buttons.Add(new ButtonModel(3, 1));
            buttons.Add(new ButtonModel(4, 2));

            //-------------------------------------------------
            // Empty the list when the page loads
            buttons = new List<ButtonModel>();

            // Generate new buttons. Randomly choose color vals
            for (int bttn = 0; bttn < GRID_SIZE; bttn++)
            {
                // Random will select a number less than 5
                buttons.Add(new ButtonModel(bttn, random.Next(5)));
            }

            // Send buton list to the "index" page
            return View("Index", buttons);
        }
        public IActionResult HandleButtonClick(string buttonNumber)
        {
            // Convert the string to int
            int bttnInt = int.Parse(buttonNumber);
            buttons.ElementAt(bttnInt).ButtonState = (buttons.ElementAt(bttnInt).ButtonState + 1) % 5;

            // Test to see if all buttons are the same color
            if(colorTest.sameColor(buttons))
            {
                ViewBag.isDone = "Congratulations. All the buttons match.";
            }
            else
            {
                ViewBag.isDone = "Not all buttons are the same color yet. Keep trying.";
            }

            return View("Index", buttons);
        }
        public IActionResult winCheck()
        {
            if (colorTest.sameColor(buttons))
            {
                ViewBag.isDone = "Congratulations. All the buttons match.";
            }
            else
            {
                ViewBag.isDone = "Not all buttons are the same color yet. Keep trying.";
            }
            return PartialView("_winPartial");
        }
        public IActionResult ShowOneButton(string buttonNumber)
        {
            int bttnInt = int.Parse(buttonNumber);

            buttons.ElementAt(bttnInt).ButtonState = (buttons.ElementAt(bttnInt).ButtonState + 1) % 5;

            // Test to see if all buttons are the same color
            if (colorTest.sameColor(buttons))
            {
                ViewBag.isDone = "Congratulations. All the buttons match.";
            }
            else
            {
                ViewBag.isDone = "Not all buttons are the same color yet. Keep trying.";
            }

            return PartialView(buttons.ElementAt(bttnInt));
        }
        public IActionResult RightClickShowOneButton(string buttonNumber)
        {
            //Convert from string to integer
            int bttnInt = int.Parse(buttonNumber);

            //Make right click to gray button
            buttons.ElementAt(bttnInt).ButtonState = 0;

            // Test to see if all buttons are the same color
            if (colorTest.sameColor(buttons))
            {
                ViewBag.isDone = "Congratulations. All the buttons match.";
            }
            else
            {
                ViewBag.isDone = "Not all buttons are the same color yet. Keep trying.";
            }

            return PartialView("ShowOneButton", buttons.ElementAt(bttnInt));
        }
    }
}
